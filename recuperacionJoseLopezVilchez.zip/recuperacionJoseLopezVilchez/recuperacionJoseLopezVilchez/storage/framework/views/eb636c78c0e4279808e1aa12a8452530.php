<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        
    </head>
    <body class="font-sans antialiased dark:bg-black dark:text-white/50">
        
        <form action="<?php echo e(route('clicReset')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <select name="user" id="user">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <input type="button" name="reiniciar" id="reiniciar" value="Reiniciar">
        </form>

    </body>
</html><?php /**PATH /Users/dam2/Desktop/curso24y25/laravel/recuperacionJoseLopezVilchez/recuperacionJoseLopezVilchez/resources/views/reiniciar.blade.php ENDPATH**/ ?>