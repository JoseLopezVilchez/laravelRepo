<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Esto es resources/views/home.blade.php')); ?></div>

                <div class="card-body">

                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <h1>Tabla de usuarios</h1>
                    <table class="table">

                        <thead>
                            <tr>
                                <th scope="col" style="background-color: slategray; color: white">Name</th>
                                <th scope="col" style="background-color: slategray; color: white">Acción</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php if(count($users) > 0): ?>
                        
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($user->name); ?></td>
                                    
                                    <td scope="row">
                                        <form action="<?php echo e(route('user.destroy')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('DELETE')); ?>

                                            <input type="submit" onclick="return confirm('Se va a eliminar el registro #<?php echo e($user->id); ?>')" value="Borrar"/>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3">No hay objetos</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>

                    </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dam2/Desktop/curso24y25/laravel/LaravelJoseLopezVilchez/resources/views/home.blade.php ENDPATH**/ ?>